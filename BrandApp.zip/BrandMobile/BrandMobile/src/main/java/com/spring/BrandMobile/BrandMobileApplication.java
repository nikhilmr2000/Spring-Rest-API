package com.spring.BrandMobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrandMobileApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrandMobileApplication.class, args);
	}

}
